export default function () {
  return {
    loggedIn: false,
    permissions: [],
    details: {}
  };
}
