<template>
  <q-page class="full-height bg-indigo-1">
    <div>
        <div class="flex q-mt-sm justify-end q-pr-md full-width">
            <q-btn clickable :to="'/menu'" round color="primary" icon="keyboard_arrow_left" />
        </div>
    </div>
    <div class="q-py-sm">
      <p class="text-center text-primary text-weight-bold text-h4">
        Hello {{student.first_name}} here is your overall progress
      </p>
    </div>
    <div class="flex flex-center q-mt-lg">
      <img
        alt="Quasar logo"
        src="~assets/greeting.png"
        width="80%"
      >
    </div>
    <div class="q-pa-sm flex justify-center">
        <p class="text-center text-primary text-weight-bold text-h4">
            Very Good!
        </p>
        <q-rating
        v-model="ratingModel"
        size="xl"
        :max="5"
        color="primary"
        >
        <template v-slot:tip-1>
            <q-tooltip>Not bad</q-tooltip>
        </template>
        <template v-slot:tip-2>
            <q-tooltip>Good</q-tooltip>
        </template>
        <template v-slot:tip-3>
            <q-tooltip>Very good!</q-tooltip>
        </template>
        <template v-slot:tip-4>
            <q-tooltip>Excellent!</q-tooltip>
        </template>
        <template v-slot:tip-5>
            <q-tooltip>Perfect!</q-tooltip>
        </template>
        </q-rating>
    </div>
  </q-page>
</template>

<script>
import { mapGetters } from 'vuex'
import { mapActions } from 'vuex'

export default {
  name: 'PageIndex',
  data() {
      return {
        ratingModel: 5,
      }
  },
  computed: {
      ...mapGetters({
          loggedIn: 'user/loggedIn',
          student: 'user/details'
      }),
  },
  methods: {
    ...mapActions('user', ['logout']),
      onLogout() {
          this.logout()
      }
  },
  mounted() {
    if(!this.loggedIn) {
      this.$router.push("/login");
    }
  }
}
</script>
